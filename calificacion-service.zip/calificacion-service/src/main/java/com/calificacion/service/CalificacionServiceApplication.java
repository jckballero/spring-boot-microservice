package com.calificacion.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalificacionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalificacionServiceApplication.class, args);
	}

}
